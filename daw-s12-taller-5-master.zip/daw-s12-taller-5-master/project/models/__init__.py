from flask import Blueprint

models = Blueprint('models', __name__)