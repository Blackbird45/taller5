from flask import Blueprint

controllers = Blueprint('controllers', __name__)