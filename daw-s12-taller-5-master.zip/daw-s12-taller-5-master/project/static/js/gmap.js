function initMap() {

        let myLatLng ;

        // Map options  
        let myOptions = { 
            zoom: 16
        }; 

        // Info window element 
        var infowindow = new google.maps.InfoWindow(); 

        const map = new google.maps.Map(document.getElementById("map"), myOptions);

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                myLatLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                map.setCenter(myLatLng);
            });
        }

        
        var pinMarker = new google.maps.Marker({
            position: myLatLng,
            map: map
        });
        
        // double click event on map
        google.maps.event.addListener(map, 'dblclick', function(e) {
            var positionDoubleclick = e.latLng;
            pinMarker.setPosition(positionDoubleclick);
        });

        // Listen for click event on marker 
        google.maps.event.addListener(pinMarker, 'click', function(e) { 
            map.setCenter(new google.maps.LatLng(pinMarker.position.lat(), pinMarker.position.lng())); 
            map.setZoom(18); 

            // Create content  
            var contentString ="Coordinate: " + pinMarker.position.lng() +"," + pinMarker.position.lat(); 
        
            // Replace our Info Window's content and position 
            infowindow.setContent(contentString); 
            infowindow.setPosition(pinMarker.position); 
            infowindow.open(map) 
        }); 
        // [END maps_map_language]
    
}

        
    